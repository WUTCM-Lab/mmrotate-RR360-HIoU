#!/bin/bash

if [ $# -ne 2 ]; then
  echo "用法: $0 <config> <ckpt> "
  exit 1
fi
expconfig=$1
ckpt=$2
dirname=$(basename $(dirname ${expconfig}))
directory_path="/home/server4/mmrotate/projects/HIoU/submission"

resultlog=/home/server4/mmrotate/projects/HIoU/results/$dirname.log

if [ -d "$directory_path" ]; then
    rm -r "$directory_path"
    echo "Directory $directory_path has been removed."
fi

python /home/server4/mmrotate/projects/HIoU/tools/test.py  ${expconfig} ${ckpt}

python /home/server4/mmrotate/projects/HIoU/tools/merge_map.py > $resultlog