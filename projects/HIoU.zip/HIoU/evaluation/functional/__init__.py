# Copyright (c) OpenMMLab. All rights reserved.
from .mean_ap import eval_rbbox_head_map

__all__ = ['eval_rbbox_head_map']
