# Copyright (c) OpenMMLab. All rights reserved.
from .dota_r360_metric import DOTAR360Metric

__all__ = ['DOTAR360Metric']
