#!/bin/bash

if [ $# -ne 2 ]; then
  echo "用法: $0 <config> <ckpt> "
  exit 1
fi
expconfig=$1
ckpt=$2
showdir=$(dirname ${expconfig})/vis

python /home/server4/mmrotate/projects/HIoU/tools/test.py \
${expconfig} ${ckpt} --show-dir ${showdir}