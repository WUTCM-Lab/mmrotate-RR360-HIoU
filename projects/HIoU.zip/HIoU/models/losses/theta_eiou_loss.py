# Copyright (c) OpenMMLab. All rights reserved.
from typing import Optional

import torch
import torch.nn as nn
from torch import Tensor
import cv2
import numpy as np
from mmrotate.registry import MODELS
from mmdet.models.losses.utils import weighted_loss
from projects.HIoU.structures.bbox.rotated_boxes import rbox2qbox, RotatedBoxes

try:
    from mmcv.ops import diff_iou_rotated_2d
except:  # noqa: E722
    diff_iou_rotated_2d = None


@MODELS.register_module()
class ThetaEIoULoss(nn.Module):

    def __init__(self,
                 eps: float = 1e-6,
                 reduction: str = 'mean',
                 loss_weight: float = 1.0) -> None:
        super().__init__()
        self.eps = eps
        self.reduction = reduction
        self.loss_weight = loss_weight

    def forward(self,
                pred: Tensor,
                target: Tensor,
                weight: Optional[Tensor] = None,
                avg_factor: Optional[int] = None,
                reduction_override: Optional[str] = None,
                **kwargs) -> Tensor:
        if weight is not None and not torch.any(weight > 0):
            if pred.dim() == weight.dim() + 1:
                weight = weight.unsqueeze(1)
            return (pred * weight).sum()  # 0
        assert reduction_override in (None, 'none', 'mean', 'sum')
        reduction = (
            reduction_override if reduction_override else self.reduction)
        if weight is not None and weight.dim() > 1:
            assert weight.shape == pred.shape
            weight = weight.mean(-1)
        loss = self.loss_weight * theta_eiou_loss(
            pred,
            target,
            weight,
            eps=self.eps,
            reduction=reduction,
            avg_factor=avg_factor,
            **kwargs)
        return loss


@weighted_loss
def theta_eiou_loss(pred: Tensor,
                    target: Tensor,
                    eps: float = 1e-7) -> Tensor:
    # get riou
    ious = diff_iou_rotated_2d(pred.unsqueeze(0), target.unsqueeze(0))
    ious = ious.squeeze(0).clamp(min=eps)

    # get pred x, y, w, h
    pred_x, pred_y, pred_w, pred_h, pred_t, = pred.unbind(dim=-1)  # [N]
    target_x, target_y, target_w, target_h, target_t = target.unbind(dim=-1)

    # get diag
    inter_diag = (pred_x - target_x).pow(2) + (pred_y - target_y).pow(2)  # [N]

    # get ph2 pw2
    ph2 = (pred_h - target_h).pow(2)
    pw2 = (pred_w - target_w).pow(2)

    # get theta l1 loss 
    theta = (1 - torch.cos(torch.abs(pred_t - target_t))) / 2

    pred_poly = rbox2qbox(pred.detach())
    target_poly = rbox2qbox(target.detach())
    all_poly = torch.cat([pred_poly, target_poly], dim=-2).reshape(-1, 8, 2)
    # Convert to numpy array and ensure the correct shape
    all_poly_np = all_poly.cpu().numpy().astype(np.float32)
    with torch.no_grad():
        if all_poly_np.ndim == 3:  # if the array is 3D, we need to convert it to 2D
            all_poly_np = all_poly_np.reshape(-1, 2)

        rect = cv2.minAreaRect(all_poly_np)
        (center, wh, angle) = rect
        outer_w, outer_h = wh
        outer_w = np.minimum(outer_w, outer_h)
        outer_h = np.maximum(outer_w, outer_h)
        wc2 = outer_w ** 2
        hc2 = outer_h ** 2
        outer_diag = wc2 + hc2 + eps

    loss = 1 - ious + (inter_diag / outer_diag) + ph2 / hc2 + pw2 / wc2 + theta

    return loss


@MODELS.register_module()
class HIoULoss(nn.Module):
    def __init__(self,
                 eps: float = 1e-6,
                 reduction: str = 'mean',
                 scale: float = 1.0,
                 loss_center=False,
                 loss_shape=False,
                 loss_theta=False,
                 lambda_center=0.5,
                 lambda_shape=0.5,
                 lambda_theta=1.0,
                 mu_shape=4,
                 alpha=2.0,
                 loss_weight: float = 1.0) -> None:
        super().__init__()
        self.eps = eps
        self.reduction = reduction
        self.loss_weight = loss_weight
        self.scale = scale
        self.loss_center = loss_center
        self.loss_shape = loss_shape
        self.loss_theta = loss_theta
        self.lambda_center = lambda_center
        self.lambda_shape = lambda_shape
        self.lambda_theta = lambda_theta
        self.mu_shape = mu_shape
        self.alpha = alpha

    def forward(self,
                pred: Tensor,
                target: Tensor,
                weight: Optional[Tensor] = None,
                avg_factor: Optional[int] = None,
                reduction_override: Optional[str] = None,
                **kwargs) -> Tensor:
        if weight is not None and not torch.any(weight > 0):
            if pred.dim() == weight.dim() + 1:
                weight = weight.unsqueeze(1)
            return (pred * weight).sum()  # 0
        assert reduction_override in (None, 'none', 'mean', 'sum')
        reduction = (
            reduction_override if reduction_override else self.reduction)
        if weight is not None and weight.dim() > 1:
            assert weight.shape == pred.shape
            weight = weight.mean(-1)
        loss = self.loss_weight * hiou_loss(
            pred,
            target,
            weight,
            eps=self.eps,
            scale=self.scale,
            loss_center=self.loss_center,
            loss_shape=self.loss_shape,
            loss_theta=self.loss_theta,
            lambda_center=self.lambda_center,
            lambda_shape=self.lambda_shape,
            lambda_theta=self.lambda_theta,
            mu_shape=self.mu_shape,
            alpha=self.alpha,
            reduction=reduction,
            avg_factor=avg_factor,
            **kwargs)
        return loss


@weighted_loss
def hiou_loss(pred: Tensor,
              target: Tensor,
              eps: float = 1e-7,
              loss_center=False,
              loss_shape=False,
              loss_theta=False,
              lambda_center=0.5,
              lambda_shape=0.5,
              lambda_theta=1.0,
              mu_shape=4,
              alpha=2.0,
              scale: float = 1.0) -> Tensor:
    # get riou
    ious = diff_iou_rotated_2d(pred.unsqueeze(0), target.unsqueeze(0))
    ious = ious.squeeze(0).clamp(min=eps)

    # get pred x, y, w, h
    pred_x, pred_y, pred_w, pred_h, pred_t, = pred.unbind(dim=-1)  # [N]
    target_x, target_y, target_w, target_h, target_t = target.unbind(dim=-1)

    inter_diag = (pred_x - target_x) ** 2 + (pred_y - target_y) ** 2  # [N]

    # get theta l1 loss 
    # theta = (1 - torch.cos(torch.abs(pred_t - target_t))) / 2
    theta = torch.exp(-alpha * (torch.cos(torch.abs(pred_t - target_t)) + 1))

    # shape IoU
    ww = 2 * torch.pow(target_w, scale) / (torch.pow(target_w, scale) + torch.pow(target_h, scale))
    hh = 2 * torch.pow(target_h, scale) / (torch.pow(target_w, scale) + torch.pow(target_h, scale))
    omiga_w = hh * torch.abs(pred_w - target_w) / torch.max(pred_w, target_w)
    omiga_h = ww * torch.abs(pred_w - target_h) / torch.max(pred_w, target_h)
    shape_cost = torch.pow(1 - torch.exp(-1 * omiga_w), mu_shape) + torch.pow(1 - torch.exp(-1 * omiga_h), mu_shape)
    # 

    pred_poly = rbox2qbox(pred.detach())
    target_poly = rbox2qbox(target.detach())
    all_poly = torch.cat([pred_poly, target_poly], dim=-2).reshape(-1, 8, 2)
    # Convert to numpy array and ensure the correct shape
    all_poly_np = all_poly.cpu().numpy().astype(np.float32)
    with torch.no_grad():
        if all_poly_np.ndim == 3:  # if the array is 3D, we need to convert it to 2D
            all_poly_np = all_poly_np.reshape(-1, 2)
        rect = cv2.minAreaRect(all_poly_np)
        (center, wh, angle) = rect
        outer_w, outer_h = wh
        outer_diag = outer_w ** 2 + outer_h ** 2 + eps
        # beta = (1/ (1-ious + 1))

    loss = 1 - ious
    if loss_center:
        loss = loss + lambda_center * (inter_diag / outer_diag)
    if loss_shape:
        loss = loss + lambda_shape * shape_cost
    if loss_theta:
        loss = loss + lambda_theta * theta
    return loss


if __name__ == '__main__':
    pred = torch.tensor([[1, 1, 1, 1, 0]], dtype=torch.float32).cuda()
    target = torch.tensor([[2, 1, 1, 2, 0]], dtype=torch.float32).cuda()
    eiou = ThetaEIoULoss()
    hiou = HIoULoss()

    print(eiou(pred, target))
    print(hiou(pred, target))
    # eps = 1e-7
    # # get riou
    # ious = diff_iou_rotated_2d(pred.unsqueeze(0), target.unsqueeze(0))
    # ious = ious.squeeze(0).clamp(min=eps) 

    # # get poly
    # pred_poly = rbox2qbox(pred)
    # target_poly = rbox2qbox(target)
    # all_poly = torch.cat([pred_poly, target_poly], dim=-2).reshape(-1, 8, 2)

    # # get pred x, y, w, h
    # pred_x, pred_y, pred_w, pred_h, pred_t, = pred.unbind(dim=-1) # [N]
    # target_x, target_y, target_w, target_h, target_t = target.unbind(dim=-1)

    # # get outer box 
    # x_min, _ = torch.min(all_poly[:, :, 0], dim=-1)                     # [N]
    # x_max, _ = torch.max(all_poly[:, :, 0], dim=-1)
    # y_min, _ = torch.min(all_poly[:, :, 1], dim=-1)
    # y_max, _ = torch.max(all_poly[:, :, 1], dim=-1)

    # # get hc, wc
    # hc = (y_max - y_min) + eps
    # wc = (x_max - x_min) + eps

    # # get diag
    # inter_diag = (pred_x - target_x)**2 + (pred_y - target_y)**2        # [N]
    # outer_diag = hc**2 + wc**2 + eps                                    # [N]

    # # get ph2 pw2
    # ph2 = (pred_h - target_h)**2                                        # [N]
    # pw2 = (pred_w - target_w)**2 

    # loss = 1 + (inter_diag / outer_diag) + ph2 / hc + pw2 / wc
    # print(loss)

    # def bbox_overlaps_ciou(bboxes1, bboxes2):
    #     rows = bboxes1.shape[0]
    #     cols = bboxes2.shape[0]
    #     cious = torch.zeros((rows, cols))
    #     if rows * cols == 0:
    #         return cious
    #     exchange = False
    #     if bboxes1.shape[0] > bboxes2.shape[0]:
    #         bboxes1, bboxes2 = bboxes2, bboxes1
    #         cious = torch.zeros((cols, rows))
    #         exchange = True

    #     w1 = bboxes1[:, 2] - bboxes1[:, 0]
    #     h1 = bboxes1[:, 3] - bboxes1[:, 1]
    #     w2 = bboxes2[:, 2] - bboxes2[:, 0]
    #     h2 = bboxes2[:, 3] - bboxes2[:, 1]

    #     area1 = w1 * h1
    #     area2 = w2 * h2

    #     center_x1 = (bboxes1[:, 2] + bboxes1[:, 0]) / 2
    #     center_y1 = (bboxes1[:, 3] + bboxes1[:, 1]) / 2
    #     center_x2 = (bboxes2[:, 2] + bboxes2[:, 0]) / 2
    #     center_y2 = (bboxes2[:, 3] + bboxes2[:, 1]) / 2

    #     inter_max_xy = torch.min(bboxes1[:, 2:],bboxes2[:, 2:])
    #     inter_min_xy = torch.max(bboxes1[:, :2],bboxes2[:, :2])
    #     out_max_xy = torch.max(bboxes1[:, 2:],bboxes2[:, 2:])
    #     out_min_xy = torch.min(bboxes1[:, :2],bboxes2[:, :2])

    #     inter = torch.clamp((inter_max_xy - inter_min_xy), min=0)
    #     inter_area = inter[:, 0] * inter[:, 1]
    #     inter_diag = (center_x2 - center_x1)**2 + (center_y2 - center_y1)**2
    #     outer = torch.clamp((out_max_xy - out_min_xy), min=0)
    #     outer_diag = (outer[:, 0] ** 2) + (outer[:, 1] ** 2)
    #     union = area1+area2-inter_area
    #     u = (inter_diag) / outer_diag
    #     iou = inter_area / union
    #     with torch.no_grad():
    #         arctan = torch.atan(w2 / h2) - torch.atan(w1 / h1)
    #         v = (4 / (math.pi ** 2)) * torch.pow((torch.atan(w2 / h2) - torch.atan(w1 / h1)), 2)
    #         S = 1 - iou
    #         alpha = v / (S + v)
    #         w_temp = 2 * w1
    #     ar = (8 / (math.pi ** 2)) * arctan * ((w1 - w_temp) * h1)
    #     cious = iou - (u + alpha * ar)
    #     cious = torch.clamp(cious,min=-1.0,max = 1.0)
    #     if exchange:
    #         cious = cious.T
    #     return cious
