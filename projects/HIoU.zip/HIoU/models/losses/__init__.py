# Copyright (c) OpenMMLab. All rights reserved.
from .theta_smooth_l1_loss import ThetaSmoothL1Loss, ThetaL1Loss
from .theta_eiou_loss import ThetaEIoULoss, HIoULoss
__all__ = [ 
    'ThetaEIoULoss', 'HIoULoss'
]
