# Copyright (c) OpenMMLab. All rights reserved.
import copy
from typing import List, Optional, Tuple

import torch
from mmcv.cnn import ConvModule, Scale, is_norm
from mmdet.models import inverse_sigmoid
from mmdet.models.dense_heads import RTMDetHead
from mmdet.models.task_modules import anchor_inside_flags
from mmdet.models.utils import (filter_scores_and_topk, multi_apply,
                                select_single_mlvl, sigmoid_geometric_mean,
                                unmap, images_to_levels)
from mmdet.structures.bbox import bbox_cxcywh_to_xyxy, cat_boxes, distance2bbox
from mmdet.utils import (ConfigType, InstanceList, OptConfigType,
                         OptInstanceList, reduce_mean)
from mmengine import ConfigDict
from mmengine.model import bias_init_with_prob, constant_init, normal_init
from mmengine.structures import InstanceData
from torch import Tensor, nn

from mmrotate.registry import MODELS, TASK_UTILS
from mmrotate.structures import distance2obb
from projects.HIoU.structures import RotatedBoxes
from .rotated_rtmdet_head import R360RTMDetHead

from .common import DSConv

class SSCBlock(nn.Module):
    def __init__(self, dim, k=3) -> None:
        super().__init__()
        self.conv_x = DSConv(dim, dim, 0, k)
        self.conv_y = DSConv(dim, dim, 1, k)
        
        self.conv1 = nn.Conv2d(dim, dim//2, 1)
        self.conv2 = nn.Conv2d(dim, dim//2, 1)

        self.conv1 = nn.Conv2d(dim, dim//2, 1)
        self.conv2 = nn.Conv2d(dim, dim//2, 1)
        self.conv_squeeze = nn.Conv2d(2, 2, 7, padding=3)
        self.conv = nn.Conv2d(dim//2, dim, 1)
        
    def forward(self, x):
        
        attn1 = self.conv_x(x)
        attn2 = self.conv_y(x)
        
        attn1 = self.conv1(attn1)
        attn2 = self.conv2(attn2)
        
        attn = torch.cat([attn1, attn2], dim=1)
        avg_attn = torch.mean(attn, dim=1, keepdim=True)
        max_attn, _ = torch.max(attn, dim=1, keepdim=True)
        agg = torch.cat([avg_attn, max_attn], dim=1)
        sig = self.conv_squeeze(agg).sigmoid()
        attn = attn1 * sig[:,0,:,:].unsqueeze(1) + attn2 * sig[:,1,:,:].unsqueeze(1)
        attn = self.conv(attn)
        
        return x * attn

@MODELS.register_module()
class SnakeRTMDetHead_1226(R360RTMDetHead):
    def _init_layers(self):
        """Initialize layers of the head."""
        self.cls_convs = nn.ModuleList()
        self.reg_convs = nn.ModuleList()
        
        self.cls_convs.append(SSCBlock(self.feat_channels))
        self.reg_convs.append(SSCBlock(self.feat_channels))
        
        for i in range(self.stacked_convs):
            chn = self.in_channels if i == 0 else self.feat_channels
            self.cls_convs.append(
                ConvModule(
                    chn,
                    self.feat_channels,
                    3,
                    stride=1,
                    padding=1,
                    conv_cfg=self.conv_cfg,
                    norm_cfg=self.norm_cfg,
                    act_cfg=self.act_cfg))
            self.reg_convs.append(
                ConvModule(
                    chn,
                    self.feat_channels,
                    3,
                    stride=1,
                    padding=1,
                    conv_cfg=self.conv_cfg,
                    norm_cfg=self.norm_cfg,
                    act_cfg=self.act_cfg))
        
        
        pred_pad_size = self.pred_kernel_size // 2
        self.rtm_cls = nn.Conv2d(
            self.feat_channels,
            self.num_base_priors * self.cls_out_channels,
            self.pred_kernel_size,
            padding=pred_pad_size)
        self.rtm_reg = nn.Conv2d(
            self.feat_channels,
            self.num_base_priors * 4,
            self.pred_kernel_size,
            padding=pred_pad_size)
        if self.with_objectness:
            self.rtm_obj = nn.Conv2d(
                self.feat_channels,
                1,
                self.pred_kernel_size,
                padding=pred_pad_size)

        self.scales = nn.ModuleList(
            [Scale(1.0) for _ in self.prior_generator.strides])
        pred_pad_size = self.pred_kernel_size // 2
        self.rtm_ang = nn.Conv2d(
            self.feat_channels,
            self.num_base_priors * self.angle_coder.encode_size,
            self.pred_kernel_size,
            padding=pred_pad_size)
        if self.is_scale_angle:
            self.scale_angle = Scale(1.0)


