# Copyright (c) OpenMMLab. All rights reserved.
from typing import List, Optional, Tuple, Union

import torch
import torch.nn as nn
from mmcv.cnn import ConvModule
from mmdet.models.utils import select_single_mlvl
from mmdet.utils import InstanceList, OptInstanceList
from mmengine.config import ConfigDict
from torch import Tensor

from mmrotate.registry import MODELS
# from mmrotate.structures.bbox import RotatedBoxes
from projects.HIoU.structures import RotatedBoxes

# from ..utils import ORConv2d, RotationInvariantPooling
from mmrotate.models.dense_heads.rotated_fcos_head import RotatedFCOSHead


@MODELS.register_module()
class RotatedFCOSS2AHead(RotatedFCOSHead):

    def filter_bboxes(self, cls_scores: List[Tensor],
                      bbox_preds: List[Tensor],
                      angle_preds: List[Tensor],
                      centerness: List[Tensor]) -> List[List[Tensor]]:
        """This function will be used in S2ANet, whose num_anchors=1.

        Args:
            cls_scores (list[Tensor]): Box scores for each scale level
                Has shape (N, num_classes, H, W)
            bbox_preds (list[Tensor]): Box energies / deltas for each scale
                level with shape (N, 5, H, W)
            angle_preds (Tensor): Angle for a single scale level the channels
              number is num_anchors * encode_size. shape(N, 3, H, W)

        Returns:
            list[list[Tensor]]: refined rbboxes of each level of each image.
        """
        num_levels = len(cls_scores)
        assert num_levels == len(bbox_preds)
        num_imgs = cls_scores[0].size(0)
        for i in range(num_levels):
            assert num_imgs == cls_scores[i].size(0) == bbox_preds[i].size(0)

        featmap_sizes = [cls_scores[i].shape[-2:] for i in range(num_levels)]

        mlvl_priors = self.prior_generator.grid_priors(
            featmap_sizes,
            dtype=cls_scores[0].dtype,
            device=cls_scores[0].device)

        bboxes_list = [[] for _ in range(num_imgs)]

        for lvl in range(num_levels):
            bbox_pred = bbox_preds[lvl]
            angle_pred = angle_preds[lvl]
            
            bbox_pred = bbox_pred.permute(0, 2, 3, 1)
            bbox_pred = bbox_pred.reshape(num_imgs, -1, 4)
            
            angle_pred = angle_pred.permute(0, 2, 3, 1)
            angle_pred = angle_pred.reshape(num_imgs, -1, self.angle_coder.encode_size)
            
            priors = mlvl_priors[lvl]
            
            for img_id in range(num_imgs):
                bbox_pred_i = bbox_pred[img_id]
                angle_pred_i = angle_pred[img_id]
                decode_angle_i = self.angle_coder.decode(angle_pred_i, keepdim=True)
                bbox_pred_i = torch.cat([bbox_pred_i, decode_angle_i], dim=-1)
                decode_bbox = self.bbox_coder.decode(priors, bbox_pred_i)
                bboxes_list[img_id].append(decode_bbox.detach())

        return bboxes_list


