from .dynamic_soft_label_assigner import R360DynamicSoftLabelAssigner
from .theta_dynamic_soft_label_assigner import R360NoAngleynamicSoftLabelAssigner
__all__ = [
    'R360DynamicSoftLabelAssigner', 'R360NoAngleynamicSoftLabelAssigner'
]