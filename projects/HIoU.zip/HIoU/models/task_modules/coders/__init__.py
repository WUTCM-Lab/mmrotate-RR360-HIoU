# Copyright (c) OpenMMLab. All rights reserved.
from .angle_coder import PSCRCoder

__all__ = [
    'PSCRCoder'
]
