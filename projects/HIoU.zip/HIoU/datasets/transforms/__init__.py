# Copyright (c) OpenMMLab. All rights reserved.
from .transforms import RotateAutoBound

__all__ = ['RotateAutoBound']
