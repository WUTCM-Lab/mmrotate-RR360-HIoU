#!/bin/bash

if [ $# -ne 1 ]; then
  echo "用法: $0 <文件路径>"
  exit 1
fi


file="$1"
dirs=$(dirname $(dirname ${file}))

cat ${file}  | grep AP50H10 > ${dirs}/result.txt

