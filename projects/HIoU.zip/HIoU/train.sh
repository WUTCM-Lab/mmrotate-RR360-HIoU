#!/bin/bash
# sudo fuser -v /dev/nvidia-uvm |awk '{for(i=1;i<=NF;i++)print "kill -9 " $i;}' | sudo sh
#export CUDA_VISIBLE_DEVICES=0


if [ $# -ne 1 ]; then
  echo "用法: $0 <文件路径>"
  exit 1
fi

expconfig="$1"

expname=$(basename ${expconfig})
expname="${expname%.py}"

day=$(date +%m%d)
DATE=$(date +%Y-%m-%d-%H-%M-%S)
trainlog=log/$DATE.log

DATE=$(date +%m%d)

nohup python /home/server4/mmrotate/projects/HIoU/tools/train.py \
${expconfig} \
--work-dir work-dirs/${DATE}-${expname} \
 > $trainlog 2>&1 &