import matplotlib.pyplot as plt

from matplotlib.font_manager import FontProperties

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False  # 正确显示负号
# 数据
categories_cn = [
    "普通货船", "散货船", "油轮", "集装箱船", "滚装船", "拖网渔船", 
    "普通渔船", "邮轮", "游艇", "挖泥船", "拖船", "近海供应船", "军舰"
]
instances = [43, 595, 151, 52, 142, 1668, 17867, 214, 2780, 53, 79, 26, 282]

plt.figure(figsize=(14, 7)) 
plt.bar(categories_cn, instances, color='skyblue')

for index, value in enumerate(instances):
    plt.text(index, value, f'{value}', ha='center', va='bottom', fontsize=20)

plt.yticks(size=20)
plt.xticks(size=16)
plt.xlabel('类别', fontsize=20)
plt.ylabel('实例数量', fontsize=20)
plt.yscale('log')  # 设置y轴为对数尺度
plt.title('各类别实例数量 ', fontsize=20)
plt.tight_layout()  # 自动调整子图参数，以填充整个图表区域

plt.savefig('./figure.jpg', dpi=1200)