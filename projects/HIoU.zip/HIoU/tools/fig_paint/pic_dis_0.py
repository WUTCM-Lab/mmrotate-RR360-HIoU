import argparse
import os
import os.path as osp
import copy
import torch
import mmcv
import matplotlib.pyplot as plt
# from mmdet.structures.bbox import BboxOverlaps2D, bbox_overlaps
# from mmdet.utils import register_all_modules as register_all_modules_mmdet
from mmrotate.structures.bbox import rbbox_overlaps
from mmrotate.models.task_modules.assigners import RBboxOverlaps2D
from projects.HIoU.structures.bbox import RotatedBoxes
from mmdet.apis.inference import inference_detector, init_detector
from mmrotate.utils import register_all_modules
from mmengine.config import Config, DictAction
from mmengine.device import get_device
from mmcv.transforms import Compose
from mmdet.utils import get_test_pipeline_cfg
from mmdet.registry import DATASETS, VISUALIZERS
# from mmdet.datasets import build_dataset 
# build_dataset were not using in mmdet 3.x
from mmengine.visualization import Visualizer
# from visualization.local_visualizer import RR360LocalVisualizer
from typing import Sequence, Tuple
from mmengine.structures import InstanceData

import cv2
import numpy as np

palette = [
    (165, 42, 42), (189, 183, 107), (0, 255, 0), (255, 0, 0),
    (138, 43, 226), (255, 128, 0), (255, 0, 255),
    (0, 255, 255), (255, 193, 193), (0, 51, 153),
    (255, 250, 205), (0, 139, 139), (255, 255, 0),
    (147, 116, 116), (0, 0, 255), (255, 250, 205), (0, 139, 139), (255, 255, 0),
    (147, 116, 116), (0, 0, 255), (0, 0, 255), (255, 250, 205), (0, 139, 139), (255, 255, 0),
    (147, 116, 116), (0, 0, 255)
]

classes = [
    '航母',
    '黄蜂级',
    '塔瓦拉级',
    '奥斯汀级',
    '惠特贝岛级',
    '圣安东尼奥级',
    '新港级',
    '提康德罗加级',
    '阿利·伯克级',
    '佩里级',
    '刘易斯和克拉克级',
    '供应级',
    '凯泽级',
    '霍普级',
    '仁慈级',
    '自由级',
    '独立级',
    '复仇者级',
    '潜艇',
    '其他',
]


def analyze_aligment(config_file, checkpoint_file, fig_save_dir, category=20):
    register_all_modules()
    iou_calculator = RBboxOverlaps2D()
    cfg = Config.fromfile(config_file)
    device = get_device()
    model = init_detector(config_file, checkpoint_file, device=device)
    model_head = model.bbox_head
    dataset = DATASETS.build(cfg.test_dataloader.dataset)
    with torch.no_grad():
        for index, item in enumerate(dataset):
            img = item['inputs'].permute(1, 2, 0).numpy()
            img_tensor = item['inputs'].unsqueeze(0).to(device).float()

            data_sample = item['data_samples'].numpy()
            gt_instances = data_sample.gt_instances
            gt_bboxes = gt_instances.get('bboxes', None).tensor.to(device)

            backbone_feat = model.extract_feat(img_tensor)
            cls_scores, bbox_preds, angle_preds = model_head(backbone_feat)

            featmap_sizes = [cls_scores[i].shape[-2:] for i in range(len(cls_scores))]
            mlvl_priors = model_head.prior_generator.grid_priors(
                featmap_sizes,
                dtype=cls_scores[0].dtype,
                device=cls_scores[0].device)

            flatten_bbox_preds = []
            for bbox_pred, stride, angle_pred, priors in zip(bbox_preds, model_head.prior_generator.strides,
                                                             angle_preds, mlvl_priors):
                flatten_bbox_pred = bbox_pred.permute(0, 2, 3, 1).reshape(1, -1, 4)
                flatten_angle_pred = angle_pred.permute(0, 2, 3, 1).reshape(1, -1, model_head.angle_coder.encode_size)
                flatten_angle_pred = model_head.angle_coder.decode(flatten_angle_pred).unsqueeze(2)
                flatten_bbox_pred = torch.cat([flatten_bbox_pred, flatten_angle_pred], dim=-1).squeeze(0)
                flatten_bbox_pred = model_head.bbox_coder.decode(priors, flatten_bbox_pred)
                flatten_bbox_preds.append(flatten_bbox_pred)

            iou_scores = []
            for flatten_bbox_pred, bbox_pred in zip(flatten_bbox_preds, bbox_preds):
                flatten_bbox_pred = flatten_bbox_pred.squeeze()  # (N, H*W, 4) -> (H*W, 4)
                overlaps = iou_calculator(flatten_bbox_pred, gt_bboxes)  # (H*W, num_gts)
                iou_scores.append(overlaps)

            cls_scores = [cls_score.squeeze().permute(1, 2, 0) for cls_score in cls_scores]

            iou_scores_tensor = torch.cat(iou_scores, dim=0)  # iou-score_tensor shape :[21504, 1]
            flatten_bbox_preds = torch.cat(flatten_bbox_preds, dim=0)

            top_k = 1
            max_iou_scores, max_iou_indices = torch.topk(iou_scores_tensor, k=top_k, largest=True, dim=0)
            bbox_list = []
            if max_iou_indices.numel() > 0:
                for i in range(top_k):
                    bbox_idx = max_iou_indices[i][0].item() if max_iou_indices.ndim > 1 else max_iou_indices[i].item()
                    bbox = flatten_bbox_preds[bbox_idx].unsqueeze(0)
                    bbox_list.append(bbox)

                instance_data = InstanceData()
                instance_data.bboxes = torch.cat(bbox_list, dim=0).cpu()
                instance_data.labels = (np.ones([top_k]) * (category - 1)).astype(int)
                visualizer = VISUALIZERS.build(cfg=dict(
                    name='visualizer',
                    type='MyRR360LocalVisualizer',
                    vis_backends=[
                        dict(type='LocalVisBackend'),
                    ]))
                gt_visualizer = VISUALIZERS.build(cfg=dict(
                    name='visualizer',
                    type='GtRR360LocalVisualizer',
                    vis_backends=[
                        dict(type='LocalVisBackend'),
                    ]))
                img = visualizer._draw_instances(img, instance_data, classes, palette)

                img = visualizer._draw_instances(img, gt_instances, classes, palette)

                plt.imshow(img)
                plt.savefig(fig_save_dir + f'/{index}.png', dpi=1200)


checkpoint = r'/home/server4/mmrotate-RR360/projects/HIoU/work-dirs/1210-rotated_rtmdet_l_thetal1-3x-fgsd/epoch_36.pth'
config = r'/home/server4/mmrotate-RR360/projects/HIoU/work-dirs/1210-rotated_rtmdet_l_thetal1-3x-fgsd/rotated_rtmdet_l_thetal1-3x-fgsd.py'
fig_save_dir = r'/home/server4/mmrotate-RR360/projects/HIoU/pic_vis'
analyze_aligment(config, checkpoint, fig_save_dir)
