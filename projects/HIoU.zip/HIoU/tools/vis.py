# Copyright (c) OpenMMLab. All rights reserved.
from argparse import ArgumentParser
import os
import mmcv
from mmdet.apis import inference_detector, init_detector
from mmrotate.registry import VISUALIZERS
from mmrotate.utils import register_all_modules
import glob


def parse_args():
    parser = ArgumentParser()
    parser.add_argument('--img_dir', help='Directory of image files',
                        default='/home/server4/mmrotate-RR360/projects/HIoU/tovis_dir')
    parser.add_argument('config', help='Config file')
    parser.add_argument('checkpoint', help='Checkpoint file')
    parser.add_argument('--out-dir', default='/home/server4/mmrotate-RR360/projects/HIoU/vis_dir/',
                        help='Directory to save output files')
    parser.add_argument('--device', default='cuda:0', help='Device used for inference')
    parser.add_argument('--palette', default='hrsc', choices=['dota', 'sar', 'hrsc', 'random'],
                        help='Color palette used for visualization')
    parser.add_argument('--score-thr', type=float, default=0.3, help='bbox score threshold')
    args = parser.parse_args()
    return args


def main(args):
    register_all_modules()
    model = init_detector(args.config, args.checkpoint, palette=args.palette, device=args.device)
    visualizer = VISUALIZERS.build(model.cfg.visualizer)
    visualizer.dataset_meta = model.dataset_meta

    # Ensure output directory exists
    os.makedirs(args.out_dir, exist_ok=True)

    # Process each image in the input directory
    for img_file in glob.glob(os.path.join(args.img_dir, '*.png')):  # Assuming images are in png format
        result = inference_detector(model, img_file)
        img = mmcv.imread(img_file)
        img = mmcv.imconvert(img, 'bgr', 'rgb')
        # Define the output file path
        base_name = os.path.basename(img_file)
        out_file = os.path.join(args.out_dir, base_name)
        # Visualize and save the results
        visualizer.add_datasample(
            'result',
            img,
            data_sample=result,
            draw_gt=False,
            show=False,
            wait_time=0,
            out_file=out_file,
            pred_score_thr=args.score_thr)

    print("damn!")


if __name__ == '__main__':
    args = parse_args()
    main(args)
