# Copyright (c) OpenMMLab. All rights reserved.

# from .rotated_boxes import RotatedBoxes, rbox2qbox
from .rotated_boxes import RotatedBoxes

__all__ = ['RotatedBoxes']
# __all__ = [
#     'RotatedBoxes', 'rbox2qbox'
# ]
