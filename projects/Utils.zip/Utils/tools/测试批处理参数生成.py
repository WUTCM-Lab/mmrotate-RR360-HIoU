import json
import os
import re


def find_files_in_directory(folder_path):
    """
    在指定目录及其子目录中查找第一个 .py 配置文件和最新的 epoch_xx.pth 文件。
    """
    config_path = None
    epoch_files = {}

    # 使用 os.walk 递归遍历文件夹
    for root, dirs, files in os.walk(folder_path):
        for file_name in files:
            file_path = os.path.join(root, file_name)

            # 判断是否为 .py 配置文件
            if file_name.endswith(".py") and config_path is None:
                config_path = file_path

            # 判断是否为 epoch_xx.pth 文件
            elif file_name.endswith(".pth"):
                match = re.search(r"epoch_(\d+)\.pth", file_name)
                if match:
                    epoch_number = int(match.group(1))
                    epoch_files[epoch_number] = file_path

    # 获取最大的 epoch 文件路径作为 ckpt_path
    ckpt_path = epoch_files[max(epoch_files.keys())] if epoch_files else None

    return config_path, ckpt_path


def generate_parameters(base_dir):
    """
    生成以 "11" 开头文件夹的参数列表，每个文件夹对应一个字典，包含 config 和 ckpt。
    """
    parameters = []

    # 遍历父级目录中的文件夹
    for folder_name in os.listdir(base_dir):
        if folder_name.startswith("11"):
            folder_path = os.path.join(base_dir, folder_name)

            # 确保它是一个目录
            if os.path.isdir(folder_path):
                config_path, ckpt_path = find_files_in_directory(folder_path)

                # 如果找到了 config 和 ckpt，加入参数列表
                if config_path and ckpt_path:
                    parameters.append({"config": config_path, "ckpt": ckpt_path})

    # 按 config 的字典序排序
    parameters.sort(key=lambda x: x["config"])
    return parameters


def main():
    base_dir = "/home/server4/mmrotate-RR360/projects/HIoU/work-dirs/mu_shape"
    parameters = generate_parameters(base_dir)

    # 输出结果字典
    print(parameters)


if __name__ == "__main__":
    main()
