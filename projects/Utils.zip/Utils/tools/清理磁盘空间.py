import os
import shutil


def check_disk_space(path="/"):
    # 获取磁盘使用情况
    usage = shutil.disk_usage(path)

    # 输出磁盘空间信息
    print(f"总空间: {usage.total / (1024 ** 3):.2f} GB")
    print(f"已用空间: {usage.used / (1024 ** 3):.2f} GB")
    print(f"剩余空间: {usage.free / (1024 ** 3):.2f} GB")


def delete_specific_files(directory):
    # 定义需要删除的文件列表
    target_files = {"epoch_12.pth", "epoch_24.pth", "epoch_30.pth"}

    # 遍历目录及其子目录
    for root, dirs, files in os.walk(directory):
        # if not os.path.basename(root).startswith("11"):
        #     continue
        for file in files:
            # 检查文件是否在目标列表中
            if file in target_files:
                file_path = os.path.join(root, file)
                try:
                    os.remove(file_path)
                    print(f"已删除文件: {file_path}")
                except Exception as e:
                    print(f"删除文件 {file_path} 时出错: {e}")


# 指定要删除文件的根目录
directory = "/home/server4/mmrotate-RR360/projects/HIoU/work-dirs"
delete_specific_files(directory)
# 检查根目录的磁盘空间
check_disk_space("/")
