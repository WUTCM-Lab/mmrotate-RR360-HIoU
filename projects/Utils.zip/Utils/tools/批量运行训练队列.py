import subprocess
import time
import datetime
import os

config_files = [
    "/home/server4/mmrotate-RR360/projects/HIoU/configs360/a_jiang_configs/uniform_backbone_and_neck/resnet101_and_neck/r101_fpn.py",
]


def run_script(config_file):
    """使用指定配置文件运行训练脚本"""

    # 提取配置文件名称并生成实验名
    expname = os.path.basename(config_file).replace('.py', '')

    # 提取文件所在文件夹
    exp_config_dir = os.path.dirname(config_file).split("/")[-1]

    # 获取当前日期
    day = datetime.datetime.now().strftime("%m%d")
    DATE = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    work_dir = f"/home/server4/mmrotate-RR360/projects/HIoU/work-dirs/{exp_config_dir}/{day}-{expname}"
    log_dir = f"{work_dir}/log"
    os.makedirs(log_dir, exist_ok=True)
    trainlog = f"{log_dir}/{DATE}.log"

    # 构建训练命令
    command = [
        "python", "/home/server4/mmrotate-RR360/projects/HIoU/tools/train.py",
        config_file,
        "--work-dir", work_dir,
    ]

    # 运行训练命令，并将输出重定向到日志文件
    with open(trainlog, "w") as log_file:
        process = subprocess.Popen(command, stdout=log_file, stderr=subprocess.STDOUT)

    print(f"正在运行配置文件: {config_file}，日志记录在: {trainlog}")
    return process


def is_process_running(process):
    """检查进程是否仍在运行"""
    return process.poll() is None


def main():
    check_interval = 2
    for config in config_files:
        config_filename = os.path.basename(config)
        print(f"正在运行配置文件: {config_filename}")
        process = run_script(config)

        start_time = time.time()

        # 循环检查当前任务是否完成
        while is_process_running(process):
            elapsed_time = int(time.time() - start_time)  # 计算运行时间
            hours, remainder = divmod(elapsed_time, 3600)
            minutes, seconds = divmod(remainder, 60)
            time_str = f"{hours:02}:{minutes:02}:{seconds:02}"

            # 使用 \r 刷新输出
            print(f"\r等待当前任务完成: {config_filename} | 已运行时间: {time_str}", end="", flush=True)
            time.sleep(check_interval)

        print(f"\n任务完成: {config_filename}")  # 当前任务完成后换行

    print("所有任务已完成！")


if __name__ == "__main__":
    main()
