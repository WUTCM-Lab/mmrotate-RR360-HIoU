import os
import subprocess
import shutil

# 定义参数数组，每个字典包含 config 和 ckpt
parameters = [{
    'config': '/home/server4/mmrotate-RR360/projects/HIoU/work-dirs/0314-rotated_rtmdet_m_l1_kld-3x-fgsd/rotated_rtmdet_m_l1_kld-3x-fgsd.py',
    'ckpt': '/home/server4/mmrotate-RR360/projects/HIoU/work-dirs/0314-rotated_rtmdet_m_l1_kld-3x-fgsd/epoch_36.pth'
},
]

# 目录和日志路径
submission_dir = "/home/server4/mmrotate-RR360/projects/HIoU/submission"
base_results_dir = "/home/server4/mmrotate-RR360/projects/HIoU/results"
test_script = "/home/server4/mmrotate-RR360/projects/HIoU/tools/test.py"
merge_script = "/home/server4/mmrotate-RR360/projects/HIoU/tools/merge_map.py"

# 遍历参数数组，依次执行每个配置项
for param in parameters:
    expconfig = param["config"]
    ckpt = param["ckpt"]
    exp_config_dir = os.path.dirname(expconfig).split("/")[-2]
    print(f"处理 {expconfig}")
    dirname = os.path.basename(os.path.dirname(expconfig))
    os.makedirs(os.path.join(f"{base_results_dir}/{exp_config_dir}"), exist_ok=True)
    resultlog = os.path.join(f"{base_results_dir}/{exp_config_dir}", f"{dirname}.log")

    # 如果 submission 目录存在，删除它
    if os.path.isdir(submission_dir):
        shutil.rmtree(submission_dir)

    # 执行 test.py 脚本，等待其完成
    subprocess.run(["python", test_script, expconfig, ckpt, "--work-dir", os.path.dirname(expconfig)])

    # 执行 merge_map.py 脚本，输出结果到日志文件
    with open(resultlog, 'w') as log_file:
        subprocess.run(["python", merge_script], stdout=log_file)

    print(f"处理完成：config={expconfig}, ckpt={ckpt}")
